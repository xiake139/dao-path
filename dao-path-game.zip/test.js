const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  
  console.log('Testing game homepage...');
  
  // Go to the game
  await page.goto('http://localhost:3000');
  
  // Wait for page to load
  await page.waitForLoadState('networkidle');
  
  // Check if key elements are present
  const title = await page.title();
  console.log('Page title:', title);
  
  // Check for login form
  const loginForm = await page.$('#login-form');
  console.log('Login form present:', !!loginForm);
  
  // Check for register form
  const registerForm = await page.$('#register-form');
  console.log('Register form present:', !!registerForm);
  
  // Check for game title
  const gameTitle = await page.$eval('.game-title h1', el => el.textContent);
  console.log('Game title:', gameTitle);
  
  // Try clicking on register tab
  await page.click('[data-tab="register"]');
  await page.waitForTimeout(500);
  
  // Check if register form is visible
  const registerVisible = await page.$eval('#register-form', el => !el.classList.contains('hidden'));
  console.log('Register form visible after click:', registerVisible);
  
  // Check for tab buttons
  const tabBtns = await page.$$('.tab-btn');
  console.log('Tab buttons count:', tabBtns.length);
  
  // Check console errors
  const errors = [];
  page.on('console', msg => {
    if (msg.type() === 'error') {
      errors.push(msg.text());
    }
  });
  
  await page.waitForTimeout(1000);
  
  if (errors.length > 0) {
    console.log('Console errors:', errors);
  } else {
    console.log('No console errors found');
  }
  
  console.log('\n✓ All tests passed!');
  
  await browser.close();
})();
