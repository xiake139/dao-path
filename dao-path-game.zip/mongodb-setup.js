const { MongoClient, ServerApiVersion } = require('mongodb');
const mongoose = require('mongoose');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

const JWT_SECRET = process.env.JWT_SECRET || 'dao-path-secret-key-2024-mongodb';
const PORT = process.env.PORT || 3000;

// MongoDB Connection
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017';
const DB_NAME = process.env.DB_NAME || 'dao-path';

let db;

// Connect to MongoDB with better error handling
async function connectDB() {
  try {
    // Try direct connection first
    const client = new MongoClient(MONGO_URI, {
      serverApi: {
        version: ServerApiVersion.v1,
        strict: true,
        deprecationErrors: true,
      }
    });
    
    await client.connect();
    await client.db("admin").command({ ping: 1 });
    console.log('Connected to MongoDB successfully');
    
    db = client.db(DB_NAME);
    
    // Create indexes
    await db.collection('users').createIndex({ username: 1 }, { unique: true });
    await db.collection('characters').createIndex({ user_id: 1 });
    await db.collection('characters').createIndex({ name: 1 });
    await db.collection('inventory').createIndex({ char_id: 1 });
    
    console.log('Database indexes created');
    return client;
  } catch (error) {
    console.error('MongoDB connection error:', error.message);
    console.error('Please check:');
    console.error('1. MONGO_URI is set correctly');
    console.error('2. Network access allows 0.0.0.0/0');
    console.error('3. Database user credentials are correct');
    process.exit(1);
  }
}
